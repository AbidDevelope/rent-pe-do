<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <h3 class="card-title m-0">Banners</h3>
                <a href="<?php echo e(route('banner.create')); ?>" class="btn btn-primary">
                    <i class="fa fa-plus"></i> Add New Banner
                </a>
            </div>
            <div class="card-body">
                <table class="table table-bordered" id="myDataTable">
                    <thead class="bg-secondary">
                        <tr>
                            <th class="text-center">SL.</th>
                            <th>Thumbnail</th>
                            <th>Title</th>
                            <th>Status</th>
                            <th>Position</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($key + 1); ?></td>
                                <td style="width: 120px">
                                    <img src="<?php echo e($banner->thumbnail); ?>" alt="thumbnail" loading="lazy" width="100" />
                                </td>
                                <td><?php echo e($banner->title); ?></td>
                                <td>
                                    <label class="switch">
                                        <a href="<?php echo e(route('banner.status.toggle', $banner->id)); ?>">
                                            <input type="checkbox" <?php echo e($banner->is_active ? 'checked' : ''); ?>>
                                            <span class="slider round"></span>
                                        </a>
                                    </label>
                                </td>
                                <td>
                                    <?php echo e($banner->position); ?>

                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('banner.edit', $banner->id)); ?>" class="btn btn-primary btn-sm text-white">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="<?php echo e(route('banner.destroy', $banner->id)); ?>" class="btn btn-danger btn-sm text-white deleteConfirm">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/banner/index.blade.php ENDPATH**/ ?>