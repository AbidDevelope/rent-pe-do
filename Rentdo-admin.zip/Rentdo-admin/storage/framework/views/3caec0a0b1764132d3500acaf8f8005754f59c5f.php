<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-6">
                                <h2 class="m-0">All Customers</h2>
                            </div>
                            <div class="col-6">
                                <form action="<?php echo e(route('customer')); ?>" method="GET">
                                    <div class="row justify-content-end">
                                        <div class="col-6 pr-1">
                                            <input type="text" name='search' placeholder="Search"
                                                value="<?php echo e(request('search')); ?>" class="form-control"/>
                                        </div>
                                        <div class="col-3 pl-1">
                                            <button type="submit" class="btn btn-info">
                                                <i class="fa fa-search"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-responsive-sm" id="myTable">
                                <thead class="bg-secondary">
                                    <tr>
                                        <th scope="col">Sl.</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Mobile</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($key+1); ?></td>
                                            <td><?php echo e($customer->user->name); ?></td>
                                            <td>
                                                <?php echo e($customer->user->email); ?>

                                            </td>
                                            <td>
                                                <?php echo e($customer->user->phone); ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('customer.show', $customer->id)); ?>" class="btn btn-primary py-1 px-2">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/customers/index.blade.php ENDPATH**/ ?>