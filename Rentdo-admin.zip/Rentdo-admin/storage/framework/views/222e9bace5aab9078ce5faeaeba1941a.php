<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <h3 class="card-title m-0">Cities</h3>
                <a href="<?php echo e(route('city.create')); ?>" class="btn btn-primary">
                    <i class="fa fa-plus"></i> Add New City
                </a>
            </div>
            <div class="card-body">
                <table class="table table-bordered" id="myDataTable">
                    <thead class="bg-secondary">
                        <tr>
                            <th class="text-center">SL.</th>
                            <th>Thumbnail</th>
                            <th>Name</th>
                            <th>Properties</th>
                            <th>Top</th>
                            <th>Status</th>
                            <th>Position</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($key + 1); ?></td>
                                <td style="width: 120px">
                                    <img src="<?php echo e($city->thumbnail); ?>" alt="thumbnail" loading="lazy" width="100" />
                                </td>
                                <td><?php echo e($city->name); ?></td>
                                <td><?php echo e($city->property); ?>+</td>
                                <td>
                                    <label class="switch">
                                        <a href="<?php echo e(route('city.top.toggle', $city->id)); ?>">
                                            <input type="checkbox" <?php echo e($city->is_top ? 'checked' : ''); ?>>
                                            <span class="slider round"></span>
                                        </a>
                                    </label>
                                </td>
                                <td>
                                    <label class="switch">
                                        <a href="<?php echo e(route('city.status.toggle', $city->id)); ?>">
                                            <input type="checkbox" <?php echo e($city->is_active ? 'checked' : ''); ?>>
                                            <span class="slider round"></span>
                                        </a>
                                    </label>
                                </td>
                                <td>
                                    <?php echo e($city->position); ?>

                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('city.edit', $city->id)); ?>" class="btn btn-primary btn-sm text-white">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="<?php echo e(route('city.destroy', $city->id)); ?>" class="btn btn-danger btn-sm text-white deleteConfirm">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/cities/index.blade.php ENDPATH**/ ?>