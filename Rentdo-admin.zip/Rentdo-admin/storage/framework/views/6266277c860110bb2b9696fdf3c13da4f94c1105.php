<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-lg-8 m-auto">

                <!-- Start Ads -->
                <form action="<?php echo e(route('ads.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card rounded ">
                        <div class="card-header">
                            <h3 class="card-title m-0">Ads Create</h3>
                        </div>
                        <div class="card-body p-4">

                            <div class="form-group mb-3">
                                <label class="m-0">Title</label>
                                <input type="text" name="title" class="form-control" placeholder="Title" value="<?php echo e(old('title')); ?>"/>
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group mb-3">
                                <label class="m-0">Thumbnail Image</label>
                                <input type="file" name="thumbnail" class="form-control"/>
                                <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>
                        <div class="card-footer d-flex justify-content-between align-items-center">
                            <button type="submit" class="btn btn-success">Submit</button>
                            <a href="<?php echo e(route('ads.index')); ?>" class="btn btn-secondary">Back</a>
                        </div>
                    </div>
                </form>
                <!-- End Subscription -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/ads/create.blade.php ENDPATH**/ ?>