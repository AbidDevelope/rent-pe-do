<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <?php
            $currency = $currency ? $currency->symbol : '$';
        ?>
        <div class="card">
            <div class="card-header">
                <h2 class="card-title m-0">All Rents</h2>
            </div>
            <div class="card-body">
                <table class="table table-bordered" id="myTable">
                    <thead class="bg-secondary">
                        <tr>
                            <th class="text-center">SL.</th>
                            <th>Title</th>
                            <th>Type</th>
                            <th>Position</th>
                            <th>Bad</th>
                            <th>Post Status</th>
                            <th>Payment Status</th>
                            <th>Status</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($key + 1); ?></td>
                                <td><?php echo e($rent->title); ?></td>
                                <td><?php echo e($rent->type); ?></td>
                                <td><?php echo e($rent->position); ?></td>
                                <td><?php echo e($rent->bad); ?></td>
                                <td>
                                    <?php if($rent->is_paid): ?>
                                        <span class="badge bg-danger text-white">premium</span>
                                        <span class="badge bg-secondary"><?php echo e($currency . $rent->ads_price); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-light">free</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($rent->is_paid): ?>
                                        <?php if($rent->payment_status == 'pending'): ?>
                                            <span class="badge bg-warning text-white">Pending</span>
                                        <?php else: ?>
                                            <span class="badge bg-success text-white">Paid</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'visitor')): ?>
                                        <label class="switch">
                                            <a href="#" class="visitorMessage">
                                                <input type="checkbox" <?php echo e($rent->is_active ? 'checked' : ''); ?>>
                                                <span class="slider round"></span>
                                            </a>
                                        </label>
                                    <?php else: ?>
                                        <label class="switch">
                                            <a href="<?php echo e(route('rent.status.toggle', $rent->id)); ?>">
                                                <input type="checkbox" <?php echo e($rent->is_active ? 'checked' : ''); ?>>
                                                <span class="slider round"></span>
                                            </a>
                                        </label>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('rent.details', $rent->id)); ?>" class="btn py-2 btn-info">
                                        <i class="fa fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/rent/index.blade.php ENDPATH**/ ?>