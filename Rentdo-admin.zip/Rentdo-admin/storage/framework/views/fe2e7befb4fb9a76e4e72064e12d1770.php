<!DOCTYPE html>
<html lang="en" dir="">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <link rel="icon" type="image/png" href="<?php echo e($setting?->favIconPath ?? asset('images/logo.svg')); ?>" />

    <title><?php echo e($setting?->name ?? env('APP_NAME')); ?></title>

    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

    <!-- Font-Awesome--Min-Css-Link -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">

    <!-- sweetalert css-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/sweetalert2.min.css')); ?>">

    <!-- table sorter stylesheet-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/datatables.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

    <!--Responsive--Css-Link -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">

</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header" id="appContent">
        <div class="app-header header-shadow">
            <div class="app-header-logo"></div>
            <div class="app-header-mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header-menu">
                <span>
                    <button type="button"
                        class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>
            <div class="app-header-content">
                <!-- Header-left-Section -->
                <div class="app-header-left">
                    <div class="header-pane ">
                        <div>
                            <button type="button" class="hamburger close-sidebar-btn hamburger--elastic"
                                data-class="closed-sidebar">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                            </button>
                        </div>
                    </div>
                </div>
                <!-- End-Header-Left-section -->

                <!-- Header-Rignt-Section -->
                <div class="app-header-right">
                    <div class="user-profile-box dropdown mx-3">
                        <div class="nav-profile-box dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <div class="profile-image">
                                <a href="#">
                                    <img class="" src="<?php echo e(asset('/icons/language.svg')); ?>" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="dropdown-menu profile-item">
                            <a href="#" class="dropdown-item">
                                <i class="fa fa-language mr-3"></i> English
                            </a>
                        </div>
                    </div>
                    <div class="user-profile-box dropdown ml-3">
                        <div class="nav-profile-box dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <div class="profile-image">
                                <a href="">
                                    <img class="profilepic" src="<?php echo e(asset('images/dummy/dummy-user.png')); ?>"
                                        alt="profile" loading="lazy" />
                                </a>
                            </div>
                            <div class="profile-content">
                                <span><?php echo e(ucfirst(auth()->user()->name)); ?></span>
                                <i class="fa-solid fa-angle-down dropIcon"></i>
                            </div>
                        </div>

                        <div class="dropdown-menu profile-item">
                            <a href="<?php echo e(route('profile.index')); ?>" class="dropdown-item">
                                <i class="fa fa-user me-2"></i> <?php echo e(__('Profile')); ?>

                            </a>
                            <a href="<?php echo e(route('setting.index')); ?>" class="dropdown-item">
                                <i class="fa fa-cog me-2"></i><?php echo e(__('Settings')); ?>

                            </a>
                            <a href="<?php echo e(route('profile.changePassword')); ?>" class="dropdown-item">
                                <i class="fa-solid fa-key me-2"></i><?php echo e(__('Change Password')); ?>

                            </a>
                            <button class="dropdown-item cursor-pointer logout">
                                <i class="fa-solid fa-right-from-bracket me-2"></i><?php echo e(__('Logout')); ?>

                            </button>
                        </div>
                    </div>
                </div>
                <!-- End-Header-Right-Section -->

            </div>
        </div>
        <div class="app-main">

            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- ****Body-Section***** -->

            <div class="app-main-outer">
                <!-- ****End-Body-Section**** -->
                <div class="app-main-inner">

                    <?php echo $__env->yieldContent('content'); ?>

                </div>
                <!-- Footer-Section -->
                <div class="app-wrapper-footer">
                    <div class="app-footer">
                        <div class="app-footer-inner">
                            <div>
                                © <?php echo e(date('Y')); ?> <?php echo e(__('developed by')); ?>

                                <a class="razinsoftText" href="https://razinsoft.com/" target="blank">Razinsoft.</a>
                            </div>
                            <div class="d-none d-sm-block">
                                <i class="fa-solid fa-phone"></i>
                                <span> +8801714231625</span>
                            </div>
                            <div class="d-none d-sm-block">
                                <i class="fa-solid fa-envelope mr-1"></i>
                                <span>razinsoftltd@gmail.com</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('assets/scripts/jquery-3.6.3.min.js')); ?>"></script>
    <!-- Bootstrap-Min-Bundil-Link -->
    <script src="<?php echo e(asset('assets/scripts/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Main-Script-Js-Link -->
    <script src="<?php echo e(asset('assets/scripts/main.js')); ?>"></script>

    <!-- Full-Screen-Js-Link -->
    <script src="<?php echo e(asset('assets/scripts/full-screen.js')); ?>"></script>

    <!-- sweetalert js-->
    <script src="<?php echo e(asset('assets/scripts/sweetalert2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/scripts/datatables.min.js')); ?>"></script>

    <!-- Theme-Color-setup -->
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var themeColor = "<?php echo e($setting?->theme_color ?? '#5352ed'); ?>";
            var themeHoverColor = "<?php echo e($setting?->theme_hover_color ?? '#dbeafe'); ?>";
            document.documentElement.style.setProperty('--theme-color', themeColor);
            document.documentElement.style.setProperty('--theme-hover-bg', themeHoverColor);
        });
    </script>

    <script src="<?php echo e(asset('assets/scripts/script.js')); ?>"></script>

    <script>
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        });
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>

    <?php if(session('success')): ?>
        <script>
            Toast.fire({
                icon: 'success',
                title: '<?php echo e(session('success')); ?>'
            })
        </script>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <script>
            Toast.fire({
                icon: 'error',
                title: "<?php echo e(session('error')); ?>"
            })
        </script>
    <?php endif; ?>

</body>

</html>
<?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/layouts/app.blade.php ENDPATH**/ ?>