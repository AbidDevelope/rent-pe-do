<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-3">
        <h3 class="mb-3">Dashboard</h3>

        <?php
            $currency = $currency ? $currency->symbol : '$';
        ?>

        <div class="row">

            <div class="col-md-6 col-lg-4 col-xl-3 mb-3">
                <div class="dashboard-summery bg-primary">
                    <h2><?php echo e($customer); ?></h2>
                    <h3> Total Customer</h3>
                    <div class="icon">
                        <i class="fas fa-user"></i>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 col-xl-3 mb-3">
                <div class="dashboard-summery bg-shop">
                    <h2><?php echo e($rent); ?></h2>
                    <h3> Total Rents</h3>
                    <div class="icon">
                        <i class="fas fa-stat-info"></i>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 col-xl-3 mb-3">
                <div class="dashboard-summery bg-midnight">
                    <h2>10</h2>
                    <h3>Active Rents</h3>
                    <div class="icon">
                        <i class="fas fa-shopping-basket"></i>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 col-xl-3 mb-3">
                <div class="dashboard-summery bg-plum-plate">
                    <h2><?php echo e($city); ?></h2>
                    <h3>Total City</h3>
                    <div class="icon">
                        <i class="fas fa-user-cog"></i>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 col-xl-3 mb-3">
                <div class="dashboard-summery bg-grow-early">
                    <h2><?php echo e($todayRents->total()); ?></h2>
                    <h3>New Rents</h3>
                    <div class="icon">
                        <i class="fas fa-plus"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="totay_rents">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Today Rents</h4>
                    <a href="<?php echo e(route('rent')); ?>" class="btn btn-primary">view All</a>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Rent Type</th>
                                <th>Property Type</th>
                                <th>Price</th>
                                <th>Created</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $todayRents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($rent->title); ?></td>
                                    <td><?php echo e($rent->rent_type->value); ?></td>
                                    <td><?php echo e($rent->property_type->value); ?></td>
                                    <td><?php echo e($currency . $rent->price); ?></td>
                                    <td>
                                        <?php echo e($rent->created_at->format('M d, Y - h:i A')); ?> <br>
                                        <small><?php echo e($rent->created_at->diffForHumans()); ?></small>
                                    </td>

                                    <td>
                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'visitor')): ?>
                                            <label class="switch">
                                                <a href="#" class="visitorMessage">
                                                    <input type="checkbox" <?php echo e($rent->is_active ? 'checked' : ''); ?>>
                                                    <span class="slider round"></span>
                                                </a>
                                            </label>
                                        <?php else: ?>
                                            <label class="switch">
                                                <a href="<?php echo e(route('rent.status.toggle', $rent->id)); ?>">
                                                    <input type="checkbox" <?php echo e($rent->is_active ? 'checked' : ''); ?>>
                                                    <span class="slider round"></span>
                                                </a>
                                            </label>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('rent.details', $rent->id)); ?>" class="btn py-2 btn-info">
                                            <i class="fa fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr class="text-center">
                                    <td colspan="100%">sorry, Today's rent not found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="mt-3 d-flex justify-content-end flex-wrap">
                        <?php echo e($todayRents->onEachSide(3)->links()); ?>

                    </div>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/dashboard/index.blade.php ENDPATH**/ ?>