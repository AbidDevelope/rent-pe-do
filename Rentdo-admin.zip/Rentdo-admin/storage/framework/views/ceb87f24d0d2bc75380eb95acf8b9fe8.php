<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-md-8 m-auto">

                <form action="<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'visitor')): ?> # <?php else: ?> <?php echo e(route('setting.update')); ?> <?php endif; ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title m-0">App Setting</h3>
                        </div>
                        <div class="card-body">
                            <label class="m-0">Ads show after rents</label>
                            <div class="input-group">
                                <input type="number" name="ads_count" class="form-control"
                                    placeholder="Ads Count after rents post" value="<?php echo e($setting?->ads_count ?? 2); ?>" />
                                <?php $__errorArgs = ['ads_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="d-flex align-items-center mt-3">
                                <input type="checkbox" name="ads_show" id="ads_show" <?php echo e($setting?->ads_show ? 'checked' : ''); ?> style="width: 18px;height: 18px;"/>
                                <label for="ads_show" class="m-0 pl-1">Ads Show</label>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/appSetting/index.blade.php ENDPATH**/ ?>