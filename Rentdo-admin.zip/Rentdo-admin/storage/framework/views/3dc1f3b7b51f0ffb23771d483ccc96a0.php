<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-lg-12">
                <form action="<?php echo e(route('notification.send')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title m-0">Send Notifications</h3>
                        </div>
                        <div class="card-body">
                            <div class="forg-group">
                                <label class="mb-1">Message</label>
                                <textarea name="message" class="form-control" rows="4" placeholder="Notification Message..."></textarea>
                                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="d-flex justify-content-end mt-2">
                                <button type="submit" class="btn btn-primary">Send</button>
                            </div>
                            <hr class="my-3">
                            <div class="d-flex justify-content-end align-items-center">
                                <span class="font-weight-600 mr-1">Device Type:</span>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle text-capitalize" id="triggerId"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                        style="width: 150px">
                                        <?php echo e(request()->device_type ?? 'all'); ?>

                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="triggerId">
                                        <a class="dropdown-item"
                                            href="<?php echo e(route('notification.index', 'device_type=all')); ?>">All</a>
                                        <a class="dropdown-item"
                                            href="<?php echo e(route('notification.index', 'device_type=android')); ?>">Android</a>
                                        <a class="dropdown-item"
                                            href="<?php echo e(route('notification.index', 'device_type=ios')); ?>">Ios</a>
                                    </div>
                                </div>
                            </div>
                            <?php $__errorArgs = ['customer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="table-responsive-md mt-2">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="px-0 text-center" style="width: 42px">
                                                <input type="checkbox" onclick="toggle(this);" />
                                            </th>
                                            <th>Name</th>
                                            <th>Phone</th>
                                            <th>Email</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="py-2 px-0 text-center">
                                                    <input type="checkbox" name="customer[]" value="<?php echo e($customer->id); ?>">
                                                </td>
                                                <td class="py-2"><?php echo e($customer->user->name); ?></td>
                                                <td class="py-2"><?php echo e($customer->user->phone); ?></td>
                                                <td><?php echo e($customer->user->email); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        function toggle(source) {
            var checkboxes = document.querySelectorAll('input[type="checkbox"]');
            for (var i = 0; i < checkboxes.length; i++) {
                if (checkboxes[i] != source)
                    checkboxes[i].checked = source.checked;
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/notifications/index.blade.php ENDPATH**/ ?>