<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <?php
            $currency = $currency ? $currency->symbol : '$';
        ?>
        <div class="card">
            <div class="card-header">
                <h3 class="card-title m-0">All Rents</h3>
            </div>
            <div class="card-body">
                <table class="table table-bordered table-responsive-lg" id="myTable">
                    <thead class="bg-secondary">
                        <tr>
                            <th class="text-center">SL.</th>
                            <th>Title</th>
                            <th>Rent Type</th>
                            <th>Property Type</th>
                            <th>Price</th>
                            <th>Created</th>
                            <th>Status</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $page = request('page') ?? 1;
                        ?>
                        <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center">
                                    <?php echo e($key + 1 + ($page ? $page * 15 - 15 : 0)); ?>

                                </td>
                                <td><?php echo e($rent->title); ?></td>
                                <td><?php echo e($rent->rent_type->value); ?></td>
                                <td><?php echo e($rent->property_type->value); ?></td>
                                <td><?php echo e($currency . $rent->price); ?></td>
                                <td>
                                    <?php echo e($rent->created_at->format('M d, Y - h:i A')); ?> <br>
                                    <small><?php echo e($rent->created_at->diffForHumans()); ?></small>
                                </td>
                                
                                <td>
                                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'visitor')): ?>
                                        <label class="switch">
                                            <a href="#" class="visitorMessage">
                                                <input type="checkbox" <?php echo e($rent->is_active ? 'checked' : ''); ?>>
                                                <span class="slider round"></span>
                                            </a>
                                        </label>
                                    <?php else: ?>
                                        <label class="switch">
                                            <a href="<?php echo e(route('rent.status.toggle', $rent->id)); ?>">
                                                <input type="checkbox" <?php echo e($rent->is_active ? 'checked' : ''); ?>>
                                                <span class="slider round"></span>
                                            </a>
                                        </label>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('rent.details', $rent->id)); ?>" class="btn btn-primary">
                                        <i class="fa fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($rents->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/rent/index.blade.php ENDPATH**/ ?>