<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <?php
            $currency = $currency ? $currency->symbol : '$';
        ?>
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <h2 class="card-title m-0">Rent Details</h2>
                <a href="<?php echo e(route('rent')); ?>" class="btn btn-light">Back</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-responsive-md">
                        <thead class="bg-secondary">
                            <tr>
                                <th>Title</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="text-bold">Thumbnail</td>

                                <td>
                                    <?php $__currentLoopData = $rent->thumbnails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e($photo['src']); ?>" class="img-thumbnail pr-1" width="120"
                                            height="80">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-bold">Title</td>
                                <td><?php echo e($rent->title); ?></td>
                            </tr>
                            <tr>
                                <td class="text-bold">Description</td>
                                <td><?php echo e($rent->description); ?></td>
                            </tr>
                            <tr>
                                <td class="text-bold">Post Status</td>
                                <td>
                                    <?php if($rent->is_paid): ?>
                                        <span class="badge bg-danger text-white">premium</span>
                                        <span class="badge bg-secondary"><?php echo e($currency . $rent->ads_price); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-light">free</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-bold">Active Status</td>
                                <td>
                                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'visitor')): ?>
                                        <label class="switch">
                                            <a href="#" class="visitorMessage">
                                                <input type="checkbox" <?php echo e($rent->is_active ? 'checked' : ''); ?>>
                                                <span class="slider round"></span>
                                            </a>
                                        </label>
                                    <?php else: ?>
                                        <label class="switch">
                                            <a href="<?php echo e(route('rent.status.toggle', $rent->id)); ?>">
                                                <input type="checkbox" <?php echo e($rent->is_active ? 'checked' : ''); ?>>
                                                <span class="slider round"></span>
                                            </a>
                                        </label>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-bold">Home Details</td>
                                <td>
                                    <table class="w-100">
                                        <tr class="bg-secondary">
                                            <td>Type</td>
                                            <td>Position</td>
                                            <td>Washroom</td>
                                            <td>Balcony</td>
                                            <td>Bad</td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e($rent->type); ?></td>
                                            <td><?php echo e($rent->position); ?></td>
                                            <td><?php echo e($rent->washroom); ?></td>
                                            <td><?php echo e($rent->balcony); ?></td>
                                            <td><?php echo e($rent->bad); ?></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-bold">Rent Info</td>
                                <td>
                                    <table class="w-100">
                                        <tr class="bg-secondary">
                                            <td>Available from</td>
                                            <td>City</td>
                                            <td>Area</td>
                                            <td>Address</td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e(Carbon\Carbon::parse($rent->rentInfo->available_from)->format('M d, Y')); ?>

                                            </td>
                                            <td><?php echo e($rent->rentInfo->city->name); ?></td>
                                            <td><?php echo e($rent->rentInfo->area->name); ?></td>
                                            <td><?php echo e($rent->rentInfo->address); ?></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-bold">Facilities</td>
                                <td>
                                    <table class="w-100">
                                        <tr class="bg-secondary">
                                            <td>Lift</td>
                                            <td>Generator</td>
                                            <td>Guard</td>
                                            <td>Parking</td>
                                            <td>Gas</td>
                                            <td>Internet</td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e($rent->facility->lift ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($rent->facility->generator ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($rent->facility->guard ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($rent->facility->parking ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($rent->facility->gas ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($rent->facility->internet ? 'Yes' : 'No'); ?></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-bold">Cost</td>
                                <td>
                                    <table class="w-100">
                                        <tr class="bg-secondary">
                                            <td>Rent price</td>
                                            <td>Electric</td>
                                            <td>Water</td>
                                            <td>Gas</td>
                                            <td>Service</td>
                                            <td>Negotiable</td>
                                            <td>Others</td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e($currency); ?><?php echo e($rent->cost->rent_price); ?></td>
                                            <td><?php echo e($currency); ?><?php echo e($rent->cost->electric); ?></td>
                                            <td><?php echo e($currency); ?><?php echo e($rent->cost->water); ?></td>
                                            <td><?php echo e($currency); ?><?php echo e($rent->cost->gas); ?></td>
                                            <td><?php echo e($currency); ?><?php echo e($rent->cost->service); ?></td>
                                            <td><?php echo e($rent->cost->negotiable ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($currency); ?><?php echo e($rent->cost->others); ?></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-bold">For Rent</td>
                                <td>
                                    <table class="w-100">
                                        <tr class="bg-secondary">
                                            <td>Male student</td>
                                            <td>Female student</td>
                                            <td>Man job</td>
                                            <td>Women job</td>
                                            <td>Any</td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e($rent->forRent->male_student ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($rent->forRent->female_student ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($rent->forRent->man_job ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($rent->forRent->women_job ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($rent->forRent->any ? 'Yes' : 'No'); ?></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-bold">Religions</td>
                                <td>
                                    <table class="w-100">
                                        <tr class="bg-secondary">
                                            <td>Islam</td>
                                            <td>Hindu</td>
                                            <td>Christian</td>
                                            <td>Bouddho</td>
                                            <td>Any</td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e($rent->religion->islam ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($rent->religion->hindu ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($rent->religion->christian ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($rent->religion->bouddho ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($rent->religion->any ? 'Yes' : 'No'); ?></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/rent/details.blade.php ENDPATH**/ ?>