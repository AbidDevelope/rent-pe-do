<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <div class="w-100">
                            <h2 class="float-left">Customer Details</h2>
                            <div class="text-right">
                                <a class="btn btn-light" href="<?php echo e(url()->previous()); ?>"> Back </a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped verticle-middle table-responsive-sm">
                                <thead>
                                    <tr>
                                        <th scope="col">Title</th>
                                        <th scope="col">Details</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <tr>
                                        <th>Name</th>
                                        <td><?php echo e($customer->user->first_name ? $customer->user->name : 'N/A'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Profile Photo</th>
                                        <td>
                                            <img width="80" src="<?php echo e($customer->user->thumbnail); ?>"
                                                alt="<?php echo e($customer->user->name); ?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Email</th>
                                        <td>
                                            <?php echo e($customer->user->email); ?>

                                            <?php if($customer->user->email_verified_at): ?>
                                                <span
                                                    class="badge badge-success"><?php echo e($customer->user->email_verified_at->format('M d, Y')); ?></span>
                                            <?php else: ?>
                                                <span class="badge badge-warning">Unverified</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Mobile</th>
                                        <td>
                                            <?php echo e($customer->user->phone); ?>

                                            <?php if($customer->user->phone_verified_at): ?>
                                                <span class="badge badge-success">Verified</span>
                                            <?php else: ?>
                                                <span class="badge badge-warning">Unverified</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Additional Mobile</th>
                                        <td><?php echo e($customer->user->additional_phone ? $customer->user->additional_phone : 'N/A'); ?>

                                        </td>
                                    </tr>


                                    <?php if(!$customer->rents->isEmpty()): ?>
                                        <tr>
                                            <th>Rents</th>
                                            <td>
                                                <!-- Button trigger modal -->
                                                <button type="button" class="btn btn-primary" data-toggle="modal"
                                                    data-target="#staticBackdrop">
                                                    Show all Rents
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Modal -->
                <div class="modal fade" id="staticBackdrop">
                    <div class="modal-dialog modal-lg modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header bg-secondary">
                                <h3 class="modal-title">All Rents</h3>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>SL.</th>
                                            <th>Title</th>
                                            <th>Type</th>
                                            <th class="text-center">View</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $customer->rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key+1); ?></td>
                                                <td class="p-2"><?php echo e($rent->title); ?></td>
                                                <td class="p-2"><?php echo e($rent->type); ?></td>
                                                <td class="p-2 text-center">
                                                    <a href="<?php echo e(route('rent.details',$rent->id)); ?>" class="btn btn-info py-2">
                                                        <i class="fa fa-eye"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="modal-footer bg-secondary py-2">
                                <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/customers/show.blade.php ENDPATH**/ ?>