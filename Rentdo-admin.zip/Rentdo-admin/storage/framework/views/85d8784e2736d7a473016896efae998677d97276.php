<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">

        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <h2 class="card-title m-0">Subscription</h2>
                <a href="<?php echo e(route('subscription.create')); ?>" class="btn btn-success">
                    <i class="fa fa-plus"></i> Add New Subscription
                </a>
            </div>

            <div class="card-body">
                <table class="table table-bordered" id="myTable">
                    <thead class="bg-secondary">
                        <tr>
                            <th class="text-center">SL.</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Number of Ads</th>
                            <th>Duration</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($key + 1); ?></td>
                                <td><?php echo e($subscription->name); ?></td>
                                <td><?php echo e($subscription->price); ?></td>
                                <td><?php echo e($subscription->number_of_ads); ?></td>
                                <td><?php echo e($subscription->duration.' '. $subscription->duration_type); ?></td>
                                <td><?php echo e(Str::limit($subscription->description, 80, '...')); ?></td>
                                <td>
                                    <label class="switch">
                                        <a href="<?php echo e(route('subscription.status.toggle', $subscription->id)); ?>">
                                            <input type="checkbox" <?php echo e($subscription->status ? 'checked' : ''); ?>>
                                            <span class="slider round"></span>
                                        </a>
                                    </label>

                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('subscription.edit', $subscription->id)); ?>" class="btn btn-info btn-sm text-white"> 
                                        <i class="fas fa-edit"></i> 
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/subscription/index.blade.php ENDPATH**/ ?>