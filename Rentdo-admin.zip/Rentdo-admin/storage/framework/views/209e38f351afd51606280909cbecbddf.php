<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <div class="card">
            <div class="card-header">
                <h2 class="card-title m-0">All Messages</h2>
            </div>
            <div class="card-body">
                <table class="table table-bordered" id="myTable">
                    <thead class="bg-secondary">
                        <tr>
                            <th>SL.</th>
                            <th>name</th>
                            <th>email</th>
                            <th>phone</th>
                            <th>occupation</th>
                            <th>message</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr> 
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($message->name); ?></td>
                            <td><?php echo e($message->email); ?></td>
                            <td><?php echo e($message->phone); ?></td>
                            <td><?php echo e($message->occupation); ?></td>
                            <td><?php echo e($message->message); ?></td>
                            <td><?php echo e($message->created_at->format('M d, Y')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/message/index.blade.php ENDPATH**/ ?>