<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-3">
        <h3 class="mb-3">Dashboard</h3>

        <?php
            $currency = $currency ? $currency->symbol : '$';
        ?>

        <div class="row">

            <div class="col-sm-6 col-lg-4 col-xl-3">
                <div class="mini-stat clearfix bx-shadow">
                    <span class="mini-stat-icon bg-danger"><i class="fa fa-user"></i></span>
                    <div class="mini-stat-info text-end text-muted">
                        <span class="countfect text-red" data-num="<?php echo e($customer); ?>"></span>
                        Total Users
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-lg-4 col-xl-3">
                <div class="mini-stat clearfix bx-shadow">
                    <span class="mini-stat-icon bg-purple"><i class="fa fa-list"></i></span>
                    <div class="mini-stat-info text-end text-muted">
                        <span class="countfect text-purple" data-num="<?php echo e($rent); ?>"></span>
                        Total Rents
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-lg-4 col-xl-3">
                <div class="mini-stat clearfix bx-shadow">
                    <span class="mini-stat-icon bg-green"><i class="fa fa-list"></i></span>
                    <div class="mini-stat-info text-end text-muted">
                        <span class="countfect text-green" data-num="<?php echo e($activeRent); ?>"></span>
                        Active Rents
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-lg-4 col-xl-3">
                <div class="mini-stat clearfix bx-shadow">
                    <span class="mini-stat-icon bg-info"><i class="fa fa-city"></i></span>
                    <div class="mini-stat-info text-end text-muted">
                        <span class="countfect text-info" data-num="<?php echo e($city); ?>"></span>
                        Total City
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-lg-4 col-xl-3">
                <div class="mini-stat clearfix bx-shadow">
                    <span class="mini-stat-icon bg-orange"><i class="fa fa-map-marked"></i></span>
                    <div class="mini-stat-info text-end text-muted">
                        <span class="countfect text-orange" data-num="<?php echo e($area); ?>"></span>
                        Total Area
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-lg-4 col-xl-3">
                <div class="mini-stat clearfix bx-shadow">
                    <span class="mini-stat-icon bg-gradient-indigo"><i class="fa fa-plus"></i></span>
                    <div class="mini-stat-info text-end text-muted">
                        <span class="countfect text-indigo" data-num="<?php echo e($todayRents->total()); ?>"></span>
                        New Rents
                    </div>
                </div>
            </div>

        </div>

        <div class="totay_rents">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h3>Today Rents</h3>
                    <a href="<?php echo e(route('rent')); ?>" class="btn py-1 px-3 btn-info">view All</a>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Type</th>
                                <th>Position</th>
                                <th>Bad</th>
                                <th>Rent price</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $todayRents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todayRent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($todayRent->title); ?></td>
                                    <td><?php echo e($todayRent->type); ?></td>
                                    <td><?php echo e($todayRent->position); ?></td>
                                    <td><?php echo e($todayRent->bad); ?></td>
                                    <td><?php echo e($currency); ?><?php echo e($todayRent->cost->rent_price); ?></td>
                                    <td>
                                        <label class="switch">
                                            <a href="<?php echo e(route('rent.status.toggle', $todayRent->id)); ?>">
                                                <input type="checkbox" <?php echo e($todayRent->is_active ? 'checked' : ''); ?>>
                                                <span class="slider round"></span>
                                            </a>
                                        </label>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr class="text-center">
                                    <td colspan="5">sorry, Today's rent not found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="mt-3 d-flex justify-content-end flex-wrap">
                        <?php echo e($todayRents->onEachSide(3)->links()); ?>

                    </div>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/dashboard/index.blade.php ENDPATH**/ ?>