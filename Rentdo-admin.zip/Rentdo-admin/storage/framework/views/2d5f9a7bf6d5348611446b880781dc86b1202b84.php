<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <div class="card">
            <div class="card-header">
                <h2 class="card-title m-0">Currency</h2>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-6">
                        <form action="<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'visitor')): ?> # <?php else: ?> <?php echo e(route('setting.currency')); ?> <?php endif; ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php
                                $currentSymbol = $currency ? $currency->symbol : '$';
                            ?>
                            <label class="m-0">Select Currency</label>
                            <div class="input-group">
                                <select name="symbol" class="form-control" style="font-size: 18px;">
                                    <option value="">----Select----</option>
                                    <?php $__currentLoopData = config('enums.currencies'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symbol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($currentSymbol == $symbol): ?> selected <?php endif; ?>
                                            value="<?php echo e($symbol); ?>"><?php echo e($symbol); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="input-group-append">
                                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'visitor')): ?>
                                        <button class="btn btn-info px-4 visitorMessage" type="button">Update</button>
                                    <?php else: ?>
                                        <button class="btn btn-info px-4" type="submit">Update</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-sm-6 d-flex align-items-center border-left">
                        <div class="">
                            <span class="text-gray">Current currency symbol is</span>
                            <span class="font-weight-bold" style="font-size: 20px"><?php echo e($currentSymbol); ?></span>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/currency/index.blade.php ENDPATH**/ ?>