<?php $__env->startSection('title', 'app setting management'); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="fa-solid fa-globe icon-gradient bg-happy-itmeo"></i>
                </div>
                <div>
                    <?php echo e(__('Setting')); ?>

                    <div class="page-title-subheading">
                        <?php echo e(__('setting Management')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-10 col-lg-8 col-sm-12 m-auto">
            <form action="<?php echo e(route('setting.update', $appSetting?->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card shadow border-0 rounded-12">
                    <div class="card-header py-3">
                        <h4 class="m-0">Settings</h4>
                    </div>
                    <div class="card-body pb-3">
                        <div class="row">
                            <div class="col-12">
                                <div class="mb-2">
                                    <label class="mb-0 text-dark fw-bold">Website Name</label>
                                    <input type="text" name="name" class="form-control"
                                        value="<?php echo e($appSetting?->name); ?>">
                                </div>

                                <div class="mb-2">
                                    <label class="mb-0 text-dark fw-bold">Website Logo</label>
                                    <input type="file" name="logo" class="form-control mb-2" accept="image/*"
                                        onchange="previewLogoFile(event)">
                                    <img src="<?php echo e($appSetting?->logoPath); ?>" alt="" id="logoPreview" width="80">
                                </div>

                                <div class="mb-2">
                                    <label class="mb-0 text-dark fw-bold">favicon</label>
                                    <input type="file" name="fav_icon" class="form-control mb-2" accept="image/*"
                                        onchange="previewFavIco(event)">
                                    <img src="<?php echo e($appSetting?->favIconPath); ?>" alt="" id="favionPreview"
                                        width="60">
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <label class="mb-0 text-dark fw-bold">Theme Color</label>
                                        <input type="color" name="theme_color" class="form-control mb-2"
                                            value="<?php echo e($appSetting?->theme_color ?? '#5352ed'); ?>" />
                                    </div>
                                    <div class="col-md-6">
                                        <label class="mb-0 text-dark fw-bold">Theme Hover Color</label>
                                        <input type="color" name="theme_hover_color" class="form-control mb-2"
                                            value="<?php echo e($appSetting?->theme_hover_color ?? '#4c4bed2e'); ?>" />
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="card-footer py-3 ">
                        <div class="d-flex justify-content-between w-100">
                            <button class="btn btn-primary">Save And Update</button>
                            <button class="btn btn-danger" id="resetColor">Reset Color</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        var previewLogoFile = function(event) {
            var reader = new FileReader();
            reader.onload = function() {
                var output = document.getElementById('logoPreview');
                output.src = reader.result;
            };
            reader.readAsDataURL(event.target.files[0]);
        };

        var previewFavIco = function(event) {
            var reader = new FileReader();
            reader.onload = function() {
                var output = document.getElementById('favionPreview');
                output.src = reader.result;
            };
            reader.readAsDataURL(event.target.files[0]);
        };

        var previewSignature = function(event) {
            var reader = new FileReader();
            reader.onload = function() {
                var output = document.getElementById('signaturePreview');
                output.src = reader.result;
            };
            reader.readAsDataURL(event.target.files[0]);
        };

        $('#resetColor').on('click', function() {
            $('input[name="theme_color"]').val('#5352ed');
            $('input[name="theme_hover_color"]').val('#dbeafe');
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/appsetting/index.blade.php ENDPATH**/ ?>