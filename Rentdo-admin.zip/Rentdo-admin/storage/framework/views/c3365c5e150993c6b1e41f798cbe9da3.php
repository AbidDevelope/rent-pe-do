<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <?php
            $currency = $currency ? $currency->symbol : '$';
        ?>
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <h3 class="card-title m-0">Rent Details</h3>
                <a href="<?php echo e(route('rent')); ?>" class="btn btn-light">Back</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-responsive-md">
                        <thead class="bg-secondary">
                            <tr>
                                <th>Title</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="text-bold">Rent Photo</td>
                                <td>
                                   <img src="<?php echo e($rent->thumbnailPhoto); ?>" class="img-thumbnail thumbnail" loading="lazy" width="140" height="80"/>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-bold">Title</td>
                                <td><?php echo e($rent->title); ?></td>
                            </tr>
                            <tr>
                                <td class="text-bold">Rent Type</td>
                                <td><?php echo e($rent->rent_type->value); ?></td>
                            </tr>
                            <tr>
                                <td class="text-bold">Property Type</td>
                                <td><?php echo e($rent->property_type->value); ?></td>
                            </tr>

                            <tr>
                                <td class="text-bold">Price</td>
                                <td><?php echo e($currency . $rent->price); ?></td>
                            </tr>

                            <tr>
                                <td class="text-bold">Address</td>
                                <td><?php echo e($rent->address); ?></td>
                            </tr>

                            <tr>
                                <td class="text-bold">Created Date</td>
                                <td>
                                    <?php echo e($rent->created_at->format('M d, Y - h:i A')); ?> |
                                    <?php echo e($rent->created_at->diffForHumans()); ?>

                                </td>
                            </tr>

                            <tr>
                                <td class="text-bold">Description</td>
                                <td><?php echo e($rent->description); ?></td>
                            </tr>

                            <tr>
                                <td class="text-bold">Active Status</td>
                                <td>
                                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'visitor')): ?>
                                        <label class="switch">
                                            <a href="#" class="visitorMessage">
                                                <input type="checkbox" <?php echo e($rent->is_active ? 'checked' : ''); ?>>
                                                <span class="slider round"></span>
                                            </a>
                                        </label>
                                    <?php else: ?>
                                        <label class="switch">
                                            <a href="<?php echo e(route('rent.status.toggle', $rent->id)); ?>">
                                                <input type="checkbox" <?php echo e($rent->is_active ? 'checked' : ''); ?>>
                                                <span class="slider round"></span>
                                            </a>
                                        </label>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-bold">Thumbnails</td>

                                <td>
                                    <?php $__currentLoopData = $rent->thumbnails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e($photo['src']); ?>" class="img-thumbnail thumbnail pr-1" loading="lazy" width="140"/>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-bold">Rent Info</td>
                                <td>
                                    <table class="w-100 table table-bordered">
                                        <tr class="bg-light">
                                            <td>Space</td>
                                            <td>bedroom</td>
                                            <td>Washroom</td>
                                            <td>kitchen</td>
                                            <td>balkony</td>
                                            <td>Position</td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e($rent->rentInfo->space); ?></td>
                                            <td><?php echo e($rent->rentInfo->bed_room); ?></td>
                                            <td><?php echo e($rent->rentInfo->wash_room); ?></td>
                                            <td><?php echo e($rent->rentInfo->kitchen); ?></td>
                                            <td><?php echo e($rent->rentInfo->balcony); ?></td>
                                            <td><?php echo e($rent->rentInfo->position); ?></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-bold">Facilities</td>
                                <td>
                                    <table class="w-100 table table-bordered">
                                        <tr class="bg-light">
                                            <td>Garden</td>
                                            <td>Swimming Pool</td>
                                            <td>GYM</td>
                                            <td>Lift</td>
                                            <td>Parking</td>
                                            <td>Security Guard</td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e($rent->facility->garden ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($rent->facility->swimming_pool ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($rent->facility->gym ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($rent->facility->lift ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($rent->facility->parking ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($rent->facility->security_guard ? 'Yes' : 'No'); ?></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-bold">Nearest Places</td>
                                <td>
                                    <table class="w-100 table table-bordered">
                                        <tr class="bg-light">
                                            <td>School</td>
                                            <td>Hospital</td>
                                            <td>Grocery Store</td>
                                            <td>ATM</td>
                                            <td>Bus Station</td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <?php echo e($rent->nearestPlace->school ? $rent->nearestPlace->school . ' Km' : 'N/A'); ?>

                                            </td>
                                            <td>
                                                <?php echo e($rent->nearestPlace->hospital ? $rent->nearestPlace->hospital . ' Km' : 'N/A'); ?>

                                            </td>
                                            <td>
                                                <?php echo e($rent->nearestPlace->grocery_store ? $rent->nearestPlace->grocery_store . ' Km' : 'N/A'); ?>

                                            </td>
                                            <td>
                                                <?php echo e($rent->nearestPlace->atm ? $rent->nearestPlace->atm . ' Km' : 'N/A'); ?>

                                            </td>
                                            <td>
                                                <?php echo e($rent->nearestPlace->bus_station ? $rent->nearestPlace->bus_station . ' Km' : 'N/A'); ?>

                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/rent/details.blade.php ENDPATH**/ ?>