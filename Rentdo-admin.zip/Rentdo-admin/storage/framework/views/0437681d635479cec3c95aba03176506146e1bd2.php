<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">

        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <h2 class="card-title m-0">All Ads</h2>
                <a href="<?php echo e(route('ads.create')); ?>" class="btn btn-success">Add New</a>
            </div>

            <div class="card-body">
                <table class="table table-bordered" id="myTable">
                    <thead class="bg-secondary">
                        <tr>
                            <th class="text-center">SL.</th>
                            <td>Thumbnail</td>
                            <th>Title</th>
                            <th>Created</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($key + 1); ?></td>
                                <td>
                                    <img src="<?php echo e($ad->thumbnail); ?>" alt="" width="120">
                                </td>
                                <td><?php echo e($ad->title); ?></td>
                                <td><?php echo e(Carbon\Carbon::parse($ad->created_at)->diffForHumans()); ?></td>
                                <td>
                                    <a href="<?php echo e(route('ads.destroy', $ad->id)); ?>" class="btn btn-danger btn-sm">
                                        <i class="fas fa-trash-alt"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/ads/index.blade.php ENDPATH**/ ?>