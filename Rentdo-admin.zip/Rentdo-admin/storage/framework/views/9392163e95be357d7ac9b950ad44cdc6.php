<?php
    $request = request();
?>
<div class="app-sidebar">
    <div class="scrollbar-sidebar">
        <div class="branding-logo">
            <img src="<?php echo e($setting?->logoPath ?? asset('images/logo.svg')); ?>" alt="logo" loading="lazy" />
        </div>
        <div class="branding-logo-forMobile">
            <a href="<?php echo e(asset('images/logo.svg')); ?>"></a>
        </div>
        <div class="app-sidebar-inner">
            <ul class="vertical-nav-menu">
                <li>
                    <a class="menu <?php echo e($request->routeIs('root') ? 'active' : ''); ?>" href="<?php echo e(route('root')); ?>">
                        <span>
                            <img src="/icons/menu.svg" class="menu-icon" alt="icon" />
                            <?php echo e(__('Dashboard')); ?>

                        </span>
                    </a>
                </li>

                <li>
                    <a class="menu <?php echo e($request->routeIs('banner.*') ? 'active' : ''); ?>" href="<?php echo e(route('banner.index')); ?>">
                        <span>
                            <img src="/icons/menu.svg" class="menu-icon" alt="icon" />
                            <?php echo e(__('Banners')); ?>

                        </span>
                    </a>
                </li>

                <li>
                    <a class="menu <?php echo e($request->routeIs('customer*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('customer')); ?>">
                        <span>
                            <img src="/icons/users.svg" class="menu-icon" alt="icon" />
                            <?php echo e(__('Customers')); ?>

                        </span>
                    </a>
                </li>

                <li>
                    <a class="menu <?php echo e($request->routeIs('rent*') ? 'active' : ''); ?>" href="<?php echo e(route('rent')); ?>">
                        <span>
                            <img src="/icons/product.svg" class="menu-icon" alt="icon" />
                            <?php echo e(__('Rents')); ?>

                        </span>
                    </a>
                </li>

                <li>
                    <a class="menu <?php echo e($request->routeIs('notification.*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('notification.index')); ?>">
                        <span>
                            <img src="/icons/setting.svg" class="menu-icon" alt="icon" />
                            <?php echo e(__('Notifications')); ?>

                        </span>
                    </a>
                </li>

                <li>
                    <a class="menu <?php echo e($request->routeIs('city*') ? 'active' : ''); ?>" href="<?php echo e(route('city.index')); ?>">
                        <span>
                            <img src="/icons/report.svg" class="menu-icon" alt="icon" />
                            <?php echo e(__('Cities')); ?>

                        </span>
                    </a>
                </li>

                <li>
                    <a class="menu <?php echo e($request->routeIs('setting.*') ? 'active' : ''); ?>" data-bs-toggle="collapse"
                        href="#settingMenu">
                        <span>
                            <img src="/icons/Setting.svg" class="menu-icon" alt="icon" />
                            <?php echo e(__('Settings')); ?>

                        </span>
                        <img src="/icons/arrowDown.svg" alt="" class="downIcon">
                    </a>
                    <div class="collapse dropdownMenuCollapse <?php echo e($request->routeIs('setting.*') ? 'show' : ''); ?>"
                        id="settingMenu">
                        <div class="listBar">
                            <a href="<?php echo e(route('setting.currency')); ?>"
                                class="subMenu <?php echo e($request->routeIs('setting.currency') ? 'active' : ''); ?>">
                                <?php echo e(__('Currency')); ?>

                            </a>
                            <a href="<?php echo e(route('setting.socialLink')); ?>"
                                class="subMenu <?php echo e($request->routeIs('setting.socialLink') ? 'active' : ''); ?>">
                                <?php echo e(__('Social Link')); ?>

                            </a>
                            <a href="<?php echo e(route('setting.index')); ?>"
                                class="subMenu <?php echo e($request->routeIs('setting.index') ? 'active' : ''); ?>">
                                <?php echo e(__('App Setting')); ?>

                            </a>
                        </div>
                    </div>
                </li>

                <li>
                    <a class="menu logout" href="javascript:void(0)">
                        <span>
                            <img src="/icons/logout.svg" class="menu-icon" alt="icon" />
                            <?php echo e(__('Logout')); ?>

                        </span>
                    </a>
                </li>

            </ul>
        </div>
        <div class="sideBarfooter">
            <button type="button" class="fullbtn hite-icon" onclick="toggleFullScreen(document.body)">
                <i class="fa-solid fa-expand"></i>
            </button>
            <a href="<?php echo e(route('setting.index')); ?>" class="fullbtn hite-icon">
                <i class="fa-solid fa-cog"></i>
            </a>
            <a href="<?php echo e(route('profile.index')); ?>" class="fullbtn hite-icon">
                <i class="fa-solid fa-user"></i>
            </a>
            <a href="javascript:void(0)" class="fullbtn hite-icon logout">
                <i class="fa-solid fa-power-off"></i>
            </a>
        </div>

        
        <form id="logoutForm" action="<?php echo e(route('logout')); ?>" method="POST"> <?php echo csrf_field(); ?> </form>
    </div>
</div>
<?php /**PATH /home/arafat/Projects/rentdo-core/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>