<?php

return [
    'roles' => [
        'root', 'admin', 'customer', 'visitor'
    ],

    'permissions' => [
        'root' => ['root', 'admin', 'visitor']
    ],
];